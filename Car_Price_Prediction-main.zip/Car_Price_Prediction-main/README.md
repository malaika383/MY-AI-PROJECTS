🚗 Car Price Prediction using Machine Learning
🧠 Project Overview

This project predicts the price of a car based on various features like brand, fuel type, engine size, horsepower, and mileage.
It uses Machine Learning (Random Forest Regressor) and provides a beautiful Streamlit Web App interface for easy user interaction.

🎯 Objective

To build an intelligent system that estimates the resale price of cars using data science and machine learning.

📁 Project Structure
Car_Price_Prediction/
│
├── app.py                          # Streamlit app for car price prediction  
├── car_price_model.pkl             # Trained ML model (saved using pickle)  
├── CarPrice_Assignment.csv         # Dataset used for training  
├── car_prediction.ipynb            # Model training and data preprocessing notebook  
├── Data Dictionary - carprices.xlsx # Data dictionary for understanding dataset  
├── README.md                       # Project documentation  
└── requirements.txt                # List of required libraries

🧰 Technologies Used
Category	Tools / Libraries
Programming Language	Python 🐍
Data Analysis	Pandas, NumPy
Visualization	Matplotlib, Seaborn
Machine Learning	Scikit-learn
Web Framework	Streamlit
Model Saving	Pickle
⚙️ How It Works

Data Preprocessing:

Handled categorical features using Label Encoding and One-Hot Encoding.

Removed irrelevant columns and handled missing values.

Model Training:

Trained multiple ML models — Linear Regression, Decision Tree, and Random Forest.

Selected the Random Forest Regressor as the best performing model based on RMSE & R² score.

Streamlit Web App:

User inputs car details (brand, fuel type, horsepower, mileage, etc.)

Model predicts estimated car price 💰 instantly.

🧪 How to Run This Project Locally
1️⃣ Clone the Repository
git clone https://github.com/vikas-m-sharma/Car_Price_Prediction.git
cd Car_Price_Prediction

2️⃣ Create a Virtual Environment (optional but recommended)
python -m venv venv
venv\Scripts\activate      # For Windows
# or
source venv/bin/activate   # For Mac/Linux

3️⃣ Install Dependencies
pip install -r requirements.txt


(If you don’t have a requirements.txt, run this first:)

pip freeze > requirements.txt

4️⃣ Run the Streamlit App
streamlit run app.py


Then open the link (usually: http://localhost:8501
) in your browser 🌐

📊 Model Evaluation
Model	RMSE ↓	R² ↑
Linear Regression	3100.23	0.86
Decision Tree	2100.18	0.91
Random Forest	1750.56	0.95

✅ Random Forest Regressor gives the most accurate car price predictions.

🖼️ Streamlit UI Preview
[You can add a screenshot here — e.g., your Streamlit app interface]


Example interface:

User enters details like brand, fuel type, doors, engine size, horsepower, etc.

Model predicts the car price and displays it instantly.

📘 Dataset Information

Source: Provided CarPrice_Assignment.csv

Rows: 205

Columns: 26

Target Variable: price

Key Features:

brand, fueltype, aspiration, carbody, drivewheel, enginetype, etc.

enginesize, horsepower, citympg, highwaympg

💾 Model Saving
import pickle

with open('car_price_model.pkl', 'wb') as f:
    pickle.dump(rf_model, f)

🚀 Future Improvements

Integrate live car price APIs for comparison.

Add feature selection using SHAP or feature importance.

Deploy app on cloud platforms (Streamlit Cloud / Heroku / AWS).

👨‍💻 Author

Vikas Sharma
💼 Python Developer | AI & ML Enthusiast
📧 Email

🌐 GitHub
